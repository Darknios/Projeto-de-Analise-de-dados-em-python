from flask import Flask, jsonify, render_template  
import os
import requests
import threading
import time
from pymongo import MongoClient
from dotenv import load_dotenv
import pandas as pd
import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import plotly.express as px

# Carregar variáveis de ambiente
load_dotenv()
MONGO_URI = os.getenv("mongodb+srv://rafaellalnascimento:leandra18@clusterone.scyalx7.mongodb.net/?retryWrites=true&w=majority&appName=ClusterOne")
DATABASE_NAME = "meteorologia"
COLLECTION_NAME = "sao_paulo"

# Criar aplicação Flask
app = Flask(__name__)

# Conectar ao MongoDB Atlas
client = MongoClient(MONGO_URI)
db = client[DATABASE_NAME]
collection = db[COLLECTION_NAME]

# Função para coletar dados da API Open-Meteo
def coletar_dados(lat, long):
    url = f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={long}&current_weather=true"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        print(f"Erro ao coletar dados: {response.status_code}")
        return None

# Função para salvar dados no MongoDB Atlas
def salvar_no_mongo(dados):
    if "current_weather" in dados:
        try:
            doc = {
                "latitude": dados["latitude"],
                "longitude": dados["longitude"],
                "temperature": dados["current_weather"]["temperature"],
                "windspeed": dados["current_weather"]["windspeed"],
                "time": dados["current_weather"]["time"]
            }
            collection.insert_one(doc)
            print("Dados salvos no MongoDB!")
        except Exception as e:
            print(f"Erro ao salvar dados no MongoDB: {e}")

# Função para rodar em *background* (Coleta contínua)
def iniciar_streaming(latitude, longitude):
    while True:
        dados_tempo = coletar_dados(latitude, longitude)
        if dados_tempo:
            salvar_no_mongo(dados_tempo)
        time.sleep(60)  # Coleta a cada 60s

# Iniciar coleta em uma *thread separada*
threading.Thread(target=iniciar_streaming, args=(-23.55, -46.63), daemon=True).start()

# Criar endpoint Flask para obter dados do MongoDB
@app.route('/dados', methods=['GET'])
def get_dados():
    dados = list(collection.find().sort("time", -1).limit(50))  # Últimos 50 registros
    for d in dados:
        d["_id"] = str(d["_id"])  # Converter ObjectId para string
    return jsonify(dados)

# Criar aplicação Dash (Dashboard Interativo)
dash_app = dash.Dash(__name__, server=app, routes_pathname_prefix='/dashboard/')

dash_app.layout = html.Div([
    html.H1("Monitoramento Meteorológico - Tempo Real"),
    dcc.Interval(id='intervalo', interval=30000, n_intervals=0),  # Atualiza a cada 5s
    dcc.Graph(id='grafico_temperatura'),
    dcc.Graph(id='grafico_vento')
])

# Callback para atualizar gráficos dinamicamente
@dash_app.callback(
    [Output('grafico_temperatura', 'figure'),
     Output('grafico_vento', 'figure')],
    [Input('intervalo', 'n_intervals')]
)
def atualizar_graficos(n):
    url = "http://127.0.0.1:5000/dados"
    resposta = requests.get(url)
    dados = resposta.json()
    
    if not dados:
        return px.line(title="Sem dados"), px.line(title="Sem dados")

    df = pd.DataFrame(dados)
    
    fig_temp = px.line(df, x="time", y="temperature", title="Temperatura ao longo do tempo")
    fig_vento = px.line(df, x="time", y="windspeed", title="Velocidade do vento ao longo do tempo")

    return fig_temp, fig_vento

# Nova rota para renderizar a página inicial com links
@app.route('/')
def index():
    return render_template('index.html')

# Rodar aplicação
if __name__ == '__main__':
    app.run(debug=True, port=5000)
