# app.py

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

# Configuração da página
st.set_page_config(
    page_title="Análise de Transações",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Carregar o arquivo CSS
#with open("style.css") as f:
    #st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)


# Carregando os dados
@st.cache_data
def load_data():
    df = pd.read_excel('dados.rev2.xlsx')
    return df

df = load_data()

# Sidebar para filtros
st.sidebar.header("Filtros")

# Filtro de Data
min_date = df['Data'].min()
max_date = df['Data'].max()
date_range = st.sidebar.date_input("Selecione o intervalo de datas:", [min_date, max_date],format='DD/MM/YYYY')

# Filtro de Categoria
categorias = df['Categoria'].unique()
selected_categorias = st.sidebar.multiselect("Selecione as categorias:", categorias, default=categorias)

# Filtro de Tipo
tipos = df['Tipo'].unique()
selected_tipos = st.sidebar.multiselect("Selecione os tipos:", tipos, default=tipos)

# Aplicando os filtros
filtered_df = df[
    (df['Data'] >= pd.to_datetime(date_range[0])) &
    (df['Data'] <= pd.to_datetime(date_range[1])) &
    (df['Categoria'].isin(selected_categorias)) &
    (df['Tipo'].isin(selected_tipos))
]

# Métricas
col1, col2, col3 = st.columns(3)


# Converter a coluna 'Data' para datetime, se ainda não estiver
filtered_df['Data'] = pd.to_datetime(filtered_df['Data'])
# Criar uma coluna para o mês (início do mês)
filtered_df['Mês'] = filtered_df['Data'].dt.to_period('M').dt.to_timestamp()
# Agrupar os dados por mês e transação
monthly_data = filtered_df.groupby(['Mês', 'Transação'])['Valor'].sum().reset_index()

# Definir o mapeamento de cores
color_map = {
    'Recebimento': 'green',
    'Pagamento': 'red'
}

with col1:
    total_recebimentos = filtered_df[filtered_df['Transação'] == 'Recebimento']['Valor'].sum()
    # Gráfico de área para Recebimentos
    fig_recebimentos = go.Figure(go.Scatter(
        x=monthly_data[monthly_data['Transação'] == 'Recebimento']['Mês'],
        y=monthly_data[monthly_data['Transação'] == 'Recebimento']['Valor'],
        mode='lines',
        fill='tozeroy',
        line=dict(color='green'),
        name='Recebimento'
    ))

    fig_recebimentos.add_annotation(
        xref="paper", yref="paper",
        x=0.5, y=0.95,
        text=f"💵 Recebimentos: R$ {total_recebimentos:,.2f}",
        showarrow=False,
        font=dict(size=14, color="White")
    )

    fig_recebimentos.update_layout(
        showlegend=False,
        margin=dict(l=10, r=0, t=30, b=0),
        height=150,
        xaxis=dict(visible=False),
        yaxis=dict(visible=False)
    )
    st.plotly_chart(fig_recebimentos, use_container_width=True)

with col2:
    total_pagamentos = filtered_df[filtered_df['Transação'] == 'Pagamento']['Valor'].sum()
    # Gráfico de área para Pagamentos
    fig_pagamentos = go.Figure(go.Scatter(
        x=monthly_data[monthly_data['Transação'] == 'Pagamento']['Mês'],
        y=monthly_data[monthly_data['Transação'] == 'Pagamento']['Valor'],
        mode='lines',
        fill='tozeroy',
        line=dict(color='red'),
        name='Pagamento'
    ))

    fig_pagamentos.add_annotation(
        xref="paper", yref="paper",
        x=0.5, y=0.95,
        text=f"	💳 Pagamentos: R$ {total_pagamentos:,.2f}",
        showarrow=False,
        font=dict(size=14, color="White")
    )

    fig_pagamentos.update_layout(
        showlegend=False,
        margin=dict(l=0, r=0, t=30, b=0),
        height=150,
        xaxis=dict(visible=False),
        yaxis=dict(visible=False)
    )
    st.plotly_chart(fig_pagamentos, use_container_width=True)

with col3:
    saldo = total_recebimentos - total_pagamentos
    # Gráfico de área para o saldo
    fig_saldo = go.Figure(go.Scatter(
        x=monthly_data['Mês'].unique(),
        y=monthly_data.groupby('Mês')['Valor'].sum(),
        mode='lines',
        fill='tozeroy',
        line=dict(color='blue'),
        name='Saldo'
    ))
    fig_saldo.add_annotation(
        xref="paper", yref="paper",
        x=0.5, y=0.95,
        text=f"	💰 Saldos: R$ {saldo:,.2f}",
        showarrow=False,
        font=dict(size=14, color="White")
    )

    fig_saldo.update_layout(
        showlegend=False,
        margin=dict(l=0, r=0, t=30, b=0),
        height=150,
        xaxis=dict(visible=False),
        yaxis=dict(visible=False)
    )
    st.plotly_chart(fig_saldo, use_container_width=True)


# Criar a figura
fig1 = go.Figure()

# Adicionar uma linha para cada tipo de transação
for transacao in monthly_data['Transação'].unique():
    df_trans = monthly_data[monthly_data['Transação'] == transacao]
    fig1.add_trace(go.Scatter(
        x=df_trans['Mês'],
        y=df_trans['Valor'],
        mode='lines+markers',
        name=transacao,
        line=dict(color=color_map.get(transacao,'blue')),
        marker=dict(size=8),
    ))

# Atualizar o layout do gráfico
fig1.update_layout(
    title='Recebimentos e Pagamentos ao Longo dos Meses',
    xaxis_title='Mês',
    yaxis_title='Valor (R$)',
    xaxis=dict(
        tickformat='%b %Y',  # Formato do tick para exibir mês e ano
        tickmode='linear',
        dtick="M1",  # Intervalo de tick de 1 mês
        tickangle=45
    ),
    yaxis=dict(
        tickprefix="R$ ",
        separatethousands=True
    ),
    hovermode='x unified',
    template='plotly_white',
)

st.plotly_chart(fig1,use_container_width=True)

#with st.expander('Análise do gráfico: '):
    #st.write(f"Dentro da seleção do filtro {filtros} ")



with st.expander('Análise diária'):

    # Criando o gráfico com duas linhas (Pagamentos e Recebimentos)
    day_data = filtered_df.groupby(['Data', 'Transação'])['Valor'].sum().reset_index()
    figx = px.line(
        day_data,
        x='Data',
        y='Valor',
        color='Transação',  # Diferencia as linhas por tipo de transação (Pagamento e Recebimento)
        title='Movimentação ao longo do dia',
        text='Valor',
        labels={
            'Valor': 'Valor (R$)',
            'Data': 'Data',
            'Transação': 'Tipo de Transação'
        },
        color_discrete_map={
            'Pagamento':'Red',
            'Recebimento':'green'
        },   
    )

    figx.update_traces(textposition="top center")

    # Atualizando o layout do gráfico para melhorar visualização
    figx.update_layout(
        xaxis_title='Data',
        yaxis_title='Valor (R$)',
        hovermode='x unified',
        template='plotly_white'
    )

    # Exibindo o gráfico no Streamlit
    st.plotly_chart(figx, use_container_width=True)

col1, col2 = st.columns(2)

with col1:

    # Gráfico 2: Distribuição por Categoria
    fig2 = px.pie(
        filtered_df,
        names='Categoria',
        values='Valor',
        title='Distribuição de Recebimentos e Pagamentos por Categoria',
        hole=0.3
    )
    st.plotly_chart(fig2, use_container_width=True)

with col2:

    # Gráfico 3: Top 10 Razões Sociais por Valor
    top_empresas = filtered_df.groupby('Razão Social')['Valor'].sum().reset_index()
    top_empresas = top_empresas.sort_values(by='Valor', ascending=False).head(10)
    fig3 = px.bar(
        top_empresas,
        x='Razão Social',
        y='Valor',
        color='Razão Social',
        title='Top 10 Empresas por Valor de Transação',
        labels={'Valor': 'Valor (R$)', 'Razão Social': 'Empresa'}
    )
    st.plotly_chart(fig3, use_container_width=True)

# Gráfico 4: Saldo por Tipo
saldo_tipo = filtered_df.groupby('Tipo')['Valor'].apply(
    lambda x: x[filtered_df['Transação'] == 'Recebimento'].sum() - x[filtered_df['Transação'] == 'Pagamento'].sum()
).reset_index()
fig4 = px.bar(
    saldo_tipo,
    x='Tipo',
    y='Valor',
    color='Tipo',
    title='Saldo por Tipo (Cliente vs Fornecedor)',
    labels={'Valor': 'Saldo (R$)', 'Tipo': 'Tipo'}
)
st.plotly_chart(fig4, use_container_width=True)

# Exibindo os dados filtrados

with st.expander("Dados Filtrados"):
    st.dataframe(filtered_df.sort_values(by='Data'), 
                 height=400,
                )